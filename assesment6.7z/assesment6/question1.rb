p class Dancer 

  attr_accessor :name
  attr_accessor :age
  attr_accessor :queue_dance_with


def initialize(name, age)
 @name = name
 @age = age
end



def new_age
  p dancer.age + 1
end

def pirouette
  "\*twirls\*"
end

def bow
  "\*bows\*"
end

def card(name)

  queue_dance_with.each { |name| 
     queue_dance_with << name
  
end

def greetings
  p "Thanks folks to come what my ballet show!"
end


end
dancer = Dancer.new("Misty", 33)
dancer.greetings
dancer.card("Mikhail Baryshnikov")
dancer.card("Anna Pavlova")



#dancer.card("Anna Pavlova")




#dance.queue_dance_with("Mikhail Baryshnikov")
#it "can add parters to the dance card queue" do
 # dancer.queue_dance_with("Mikhail Baryshnikov")
#  expect(dancer.card).to eq ["Mikhail Baryshnikov"]
#  dancer.queue_dance_with("Anna Pavlova")
#  expect(dancer.card).to eq ["Mikhail Baryshnikov", "Anna Pavlova"]



#dance.name = "Mikhail Baryshnikov"

#dance = Dancer.new()

=begin 
queue_dance_with = []
dancer = ["Mikhail Baryshnikov", "Anna Pavlova"]

dancer.length.times do |x|
  queue_dance_with << Dancer.new(dancer[i])
end
=end